from flask_app.config.mysqlconnection import connectToMySQL
mydb = 'cookie_orders'




class Cookies:
   def __init__(self,data):
      self.id = data['id']
      self.customer_id = data['customer_id']
      self.cookie_type = data['cookie_type']
      self.num_of_boxes = data['num_of_boxes']
      self.created_at = data['created_at']
      self.updated_at = data['updated_at']
   
   @classmethod
   def get_all(cls):
      query='''
      SELECT * 
      FROM cookies;'''
      results = connectToMySQL(mydb).query_db(query)
      output = []
      for row in results:
         output.append(cls(row))
      return output
   
   @classmethod
   def save(cls,data):
      query='''
      INSERT INTO cookies 
      (customer_id,cookie_type,num_of_boxes, created_at, updated_at)
      VALUES(%(customer_id)s,%(cookie_type)s,%(num_of_boxes)s, NOW(),NOW());'''
      results = connectToMySQL(mydb).query_db(query,data)
      return results 

   # @classmethod
   # def getByID(cls,data):
   #    query = '''
   #       SELECT * 
   #       FROM cookies
   #       WHERE id = %(id)s;'''
   #    results = connectToMySQL(mydb).query_db(query,data)
   #    return cls(results[0])
   
   
   