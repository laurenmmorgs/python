from flask_app.config.mysqlconnection import connectToMySQL
mydb = 'cookie_orders'
from flask_app.models import customer
from flask_app.models.cookie import Cookies




class Customers:
   def __init__(self,data):
      self.id = data['id']
      self.name = data['name']
      self.cookies = []

   # @classmethod
   # def get_all(cls):
   #    query='''
   #    SELECT * 
   #    FROM customers;'''
   #    results = connectToMySQL(mydb).query_db(query)
   #    output = []
   #    for row in results:
   #       output.append(cls(row))
   #    return output
   
   @classmethod
   def save(cls,data):
      query='''
      INSERT INTO customers 
      (name, created_at, updated_at)
      VALUES(%(name)s,NOW(),NOW());'''
      results = connectToMySQL(mydb).query_db(query,data)
      return results 

   # @classmethod
   # def getByID(cls,data):
   #    query = '''
   #       SELECT * 
   #       FROM customers
   #       WHERE id = %(id)s;'''
   #    results = connectToMySQL(mydb).query_db(query,data)
   #    return cls(results[0])
   
   @classmethod
   def get_cookies_with_customers(cls,data):
      query= '''
      SELECT *
      FROM cookies JOIN customers ON customers.id = cookies.customer_id
      WHERE customers.id = %(id)s;'''
      results = connectToMySQL(mydb).query_db(query,data)
      print(results)
      customer = cls(results[0])
      for cookies_to_customer in results:
         cookie_data = {
            'id': cookies_to_customer['ninjas.id'],
            'first_name': cookies_to_customer['first_name'],
            'last_name': cookies_to_customer['last_name'],
            'age': cookies_to_customer['age'],
            'customer_id': cookies_to_customer['customer_id'],
            'created_at': cookies_to_customer['ninjas.created_at'],
            'updated_at': cookies_to_customer['ninjas.updated_at']
         }
         customer.cookies.append(Cookies(cookie_data))
      return customer 
