from flask_app import app  
from flask_app.models import customer
from flask import render_template, session, redirect, request, flash



