from flask_app import app  
from flask_app.models import cookie
from flask_app.models import customer
from flask import render_template, session, redirect, request, flash


@app.route('/')
def index():
   return redirect('/cookies/new')


@app.route('/cookies/new')
def login():
   return render_template('login_page.html',  cookies = cookie.Cookies.get_all())


@app.route('/cookies/order', methods = ['POST'])
def cookie_orders():
   # customer.Customers.save(request.form)
   cookie.Cookies.save(request.form)
   # customer.Customers.get_cookies_with_customers(request.form)
   return redirect('/cookies/new')



